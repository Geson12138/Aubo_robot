from robotcontrol import *


def rotate_move_on_base():
    # 旋转轴
    rotate_axis = (1, 0, 0)
    # 旋转角度
    rotate_angle = 1
    # 基坐标系
    base_coord = {
        'coord_type': 0,
        'calibrate_method': 0,
        'calibrate_points':
            {"point1": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
             "point2": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
             "point3": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)},
        'tool_desc':
            {"pos":(0.0, 0.0, 0.0),
             "ori":(1.0, 0.0, 0.0, 0.0)}
    }
    # 旋转运动
    libpyauboi5.move_rotate(base_coord, rotate_axis, rotate_angle)
    pass


def rotate_move_on_user():
    pass


def rotate_move_on_tool():
    pass


def relative_move_on_base():
    pass


def relative_move_on_user():
    pass


def relative_move_on_tool():
    pass


def arrival_ahead():

    pass


def track_move():
    pass


def forward_inverse_kin():
    pass


def tcp2canbus_mode():
    pass


def coord_base2user():
    pass


def coord_user2base():
    pass


def robot_parameters():
    pass


def reduce_mode():
    pass


def board_io():
    pass


def tool_io():
    pass


def coord_base2base():
    pass


def robot_move(test_count):
    # 初始化日志 logger
    logger_init()
    # 启动测试
    logger.info("{0} test beginning...".format(Auboi5Robot.get_local_time()))
    # 系统初始化
    Auboi5Robot.initialize()
    # 创建机械臂控制类
    robot = Auboi5Robot()
    # 创建上下文
    handle = robot.create_context()
    # 输出上下文
    logger.info("robot.rshd = {0}".format(handle))

    try:
        # 连接服务器
        ip = '192.168.221.13'
        port = 8899
        result = robot.connect(ip, port)

        if result != RobotErrorType.RobotError_SUCC:
            logger.info("connect server {0}:{1} failed.".format(ip, port))
        else:
            # 连通电源
            robot.robot_startup()
            # 循环测试
            while test_count > 0:
                test_count -= 1
                # 初始化全局配置文件
                robot.init_profile()
                # 设置关节运动最大加速度
                robot.set_joint_maxacc((1.5, 1.5, 1.5, 1.5, 1.5, 1.5))
                # 设置关节运动最大速度
                robot.set_joint_maxvelc((1.5, 1.5, 1.5, 1.5, 1.5, 1.5))
                # 设置初始位置的关节角
                joint_radian = (0.54, 0.23, -0.95, 0.40, -1.57, 0.54)
                # 轴动到初始位置
                robot.move_joint(joint_radian)
                print("轴动到初始位置")

    except RobotError as e:
        logger.error("{0} robot Error:{1}".format(robot.get_local_time(), e))

    finally:
        # 断开服务器连接
        if robot.connected:
            # 关闭机械臂
            robot.robot_shutdown()
            # 断开机械臂连接
            robot.disconnect()
        # 释放库资源
        Auboi5Robot.uninitialize()
        logger.info("{0} test completed.".format(Auboi5Robot.get_local_time()))


if __name__ == '__main__':
    robot_move(1)
    logger.info("test completed")
