import time
import libpyauboi5
from math import pi
import numpy as np

SUCC = 0
rshd = -1


def login(ip, port):
    result = False
    global rshd
    # 初始化libpyauboi5库
    if libpyauboi5.initialize() == SUCC:
        print("initialize succeeded.")
        # 创建控制上下文句柄
        rshd = libpyauboi5.create_context()
        if rshd == SUCC:
            print("create_context succeeded.")
            # 登录服务器
            if libpyauboi5.login(rshd, ip, port) == SUCC:
                result = True
                print("login succeeded.")
            else:
                print("login failed.")
        else:
            print("create_context failed.")
    else:
        print("initialize failed.")

    return result


def startup():
    result = False
    # 碰撞等级
    collision = 6
    # 工具动力学参数
    tool_dynamics = {
        "position": (0, 0, 0),
        "payload": 1.0,
        "inertia": (0, 0, 0, 0, 0, 0)
    }
    # 上电
    if libpyauboi5.robot_startup(rshd, collision, tool_dynamics) == SUCC:
        result = True
        print("startup succeeded.")
    else:
        print("startup failed.")

    return result


def callback(event):
    print("获取机械臂事件信息")
    print(event)
    pass


def event_callback():
    ret = libpyauboi5.set_robot_event_callback(rshd, callback)
    if ret == SUCC:
        print("event callback succeeded.")
    else:
        print("event callback failed.")
    pass


def joint_move():
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节运动的最大加速度
    joint_maxacc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxacc(rshd, joint_maxacc)
    # 设置关节运动的最大速度
    joint_maxvelc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_maxvelc)
    # 初始位置的关节角
    # joint_radian = (0.541678, 0.225068, -0.948709, 0.397018, -1.570800, 0.541673)
    joint_radian = (173.108713 * pi / 180, -12.075005 * pi / 180, -83.663342 * pi / 180,
                    -15.641249 * pi / 180, -89.140000 * pi / 180, -28.328713 * pi / 180)
    # 轴动到初始位置
    ret = libpyauboi5.move_joint(rshd, joint_radian)
    if ret == SUCC:
        print("joint move to the initial position.")
    else:
        print("joint move failed.")
        print(ret)
    pass


def joint_move_to_on_base1():
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节运动的最大加速度
    joint_maxacc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxacc(rshd, joint_maxacc)
    # 设置关节运动的最大速度
    joint_maxvelc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_maxvelc)
    # 初始位置的关节角
    joint_radian = (-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008)
    # 轴动到初始位置
    ret = libpyauboi5.move_joint(rshd, joint_radian)
    if ret == SUCC:
        print("joint move to the initial position.")
        pass
    else:
        print("joint move failed.")
        print(ret)
        pass

    # 设置工具参数
    tool_end_param = {"pos": (0.0, 0.0, 0.0), "ori": (1.0, 0.0, 0.0, 0.0)}
    # 设置基坐标系
    libpyauboi5.set_base_coord(rshd)
    # 设置目标位置
    target = (-0.2, -0.6, 0)
    # 轴动到目标位置
    ret = libpyauboi5.move_joint_to(rshd, 1)
    if ret == SUCC:
        print("轴动到目标位置成功")
    else:
        print("轴动到目标位置失败")
        print(ret)
    pass


def follow_mode_joint_move():
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节运动的最大加速度
    joint_maxacc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxacc(rshd, joint_maxacc)
    # 设置关节运动的最大速度
    joint_maxvelc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_maxvelc)
    # 初始位置的关节角
    joint_radian = [0.541678, 0.225068, -0.948709, 0.397018, -1.570800, 0.541673]
    # 轴动到初始位置
    ret = libpyauboi5.move_joint(rshd, joint_radian)
    if ret == SUCC:
        print("joint move to the initial position.")
        pass
    else:
        print("joint move failed.")

    for i in range(1000):
        joint_radian[0] += 0.0001
        # 跟随模式的轴动
        ret = libpyauboi5.move_follow_mode_joint_to(rshd, joint_radian)
        if ret == SUCC:
            print("follow mode move succeeded.")
        else:
            print("follow mode move failed.")
    pass


def line_move():
    # 初始化全局运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节运动最大加速度
    joint_maxacc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxacc(rshd, joint_maxacc)
    # 设置关节运动最大速度
    joint_maxvelc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_maxvelc)
    # 设置末端运动最大线加速度
    line_maxacc = 0.5
    libpyauboi5.set_end_max_line_acc(rshd, line_maxacc)
    # 设置末端运动最大线速度
    line_maxvelc = 0.2
    libpyauboi5.set_end_max_line_velc(rshd, line_maxvelc)
    # 轴动到初始位置
    joint_radian = (0.541678, 0.225068, -0.948709, 0.397018, -1.570800, 0.541673)
    ret = libpyauboi5.move_joint(rshd, joint_radian)
    if ret == SUCC:
        print("joint move to initial position.")
    else:
        print("joint move failed.")
    # 直线运动
    joint_radian = (-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008)
    ret = libpyauboi5.move_line(rshd, joint_radian)
    if ret == SUCC:
        print("line move succeeded.")
    else:
        print("line move failed.")
    pass


def rotate_move_on_base1():
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节运动的最大加速度
    joint_maxacc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxacc(rshd, joint_maxacc)
    # 设置关节运动的最大速度
    joint_maxvelc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_maxvelc)
    # 初始位置的关节角
    joint_radian = (173.108713 * pi / 180, -12.075005 * pi / 180, -83.663342 * pi / 180,
                    -15.641249 * pi / 180, -89.140000 * pi / 180, -28.328713 * pi / 180)
    # 轴动到初始位置
    ret = libpyauboi5.move_joint(rshd, joint_radian)
    if ret == SUCC:
        print("joint move to the initial position.")
        pass
    else:
        print("joint move failed.")
        print(ret)
        pass

    # 基坐标系
    base_coord = {
        'coord_type': 0,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point2": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point3": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            },
        'tool_desc':
            {
                "pos": (0.0, 0.0, 0.0),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 旋转轴
    rotate_axis = (0, 0, 1)
    # 旋转角度
    rotate_angle = 10 * pi / 180
    # 旋转运动
    ret = libpyauboi5.move_rotate(rshd, base_coord, rotate_axis, rotate_angle)
    if ret == SUCC:
        print("rotate move succeeded.")
    else:
        print("rotate move failed.")


def rotate_move_on_base2():
    # 设置工具的运动学参数
    tool_desc = {"pos": (-0.177341, 0.002327, 0.146822),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    libpyauboi5.set_tool_kinematics_param(rshd, tool_desc)
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节运动的最大加速度
    joint_maxacc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxacc(rshd, joint_maxacc)
    # 设置关节运动的最大速度
    joint_maxvelc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_maxvelc)
    # 初始位置的关节角
    joint_radian = (173.108713 * pi / 180, -12.075005 * pi / 180, -83.663342 * pi / 180,
                    -15.641249 * pi / 180, -89.140000 * pi / 180, -28.328713 * pi / 180)
    # 轴动到初始位置
    ret = libpyauboi5.move_joint(rshd, joint_radian)
    if ret == SUCC:
        print("joint move to the initial position.")
        pass
    else:
        print("joint move failed.")
        print(ret)
        pass

    # 基坐标系
    base_coord = {
        'coord_type': 0,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point2": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point3": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            },
        'tool_desc':
            {
                "pos": (0.0, 0.0, 0.0),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 旋转轴
    rotate_axis = (0, 0, 1)
    # 旋转角度
    rotate_angle = 10 * pi / 180
    # 旋转运动
    ret = libpyauboi5.move_rotate(rshd, base_coord, rotate_axis, rotate_angle)
    if ret == SUCC:
        print("rotate move succeeded.")
    else:
        print("rotate move failed.")


def rotate_move_on_user1():
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节运动的最大加速度
    joint_maxacc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxacc(rshd, joint_maxacc)
    # 设置关节运动的最大速度
    joint_maxvelc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_maxvelc)
    # 初始位置的关节角
    joint_radian = (173.108713 * pi / 180, -12.075005 * pi / 180, -83.663342 * pi / 180,
                    -15.641249 * pi / 180, -89.140000 * pi / 180, -28.328713 * pi / 180)
    # 轴动到初始位置
    ret = libpyauboi5.move_joint(rshd, joint_radian)
    if ret == SUCC:
        print("joint move to the initial position.")
        pass
    else:
        print("joint move failed.")
        print(ret)
        pass

    # 用户坐标系
    user_coord = {
        'coord_type': 2,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (-75.093279 * pi / 180, 28.544643 * pi / 180, -114.313905 * pi / 180,
                           -62.769247 * pi / 180, -87.343517 * pi / 180, -27.888262 * pi / 180),
                "point2": (-89.239837 * pi / 180, 23.936171 * pi / 180, -122.299277 * pi / 180,
                           -65.208902 * pi / 180, -85.011123 * pi / 180, -41.87417 * pi / 180),
                "point3": (-77.059212 * pi / 180, 35.509518 * pi / 180, -101.108547 * pi / 180,
                           -56.433133 * pi / 180, -87.006734 * pi / 180, -29.827440 * pi / 180)
            },
        'tool_desc':
            {
                "pos": (-0.177341, 0.002327, 0.146822),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 旋转轴
    rotate_axis = (0, 0, 1)
    # 旋转角度
    rotate_angle = 10 * pi / 180
    # 旋转运动
    ret = libpyauboi5.move_rotate(rshd, user_coord, rotate_axis, rotate_angle)
    if ret == SUCC:
        print("rotate move succeeded.")
    else:
        print("rotate move failed.")


def rotate_move_on_user2():
    # 设置工具的运动学参数
    tool_desc = {"pos": (-0.177341, 0.002327, 0.146822),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    libpyauboi5.set_tool_kinematics_param(rshd, tool_desc)
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节运动的最大加速度
    joint_maxacc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxacc(rshd, joint_maxacc)
    # 设置关节运动的最大速度
    joint_maxvelc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_maxvelc)
    # 初始位置的关节角
    joint_radian = (173.108713 * pi / 180, -12.075005 * pi / 180, -83.663342 * pi / 180,
                    -15.641249 * pi / 180, -89.140000 * pi / 180, -28.328713 * pi / 180)
    # 轴动到初始位置
    ret = libpyauboi5.move_joint(rshd, joint_radian)
    if ret == SUCC:
        print("joint move to the initial position.")
        pass
    else:
        print("joint move failed.")
        print(ret)
        pass

    # 用户坐标系
    user_coord = {
        'coord_type': 2,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (-75.093279 * pi / 180, 28.544643 * pi / 180, -114.313905 * pi / 180,
                           -62.769247 * pi / 180, -87.343517 * pi / 180, -27.888262 * pi / 180),
                "point2": (-89.239837 * pi / 180, 23.936171 * pi / 180, -122.299277 * pi / 180,
                           -65.208902 * pi / 180, -85.011123 * pi / 180, -41.87417 * pi / 180),
                "point3": (-77.059212 * pi / 180, 35.509518 * pi / 180, -101.108547 * pi / 180,
                           -56.433133 * pi / 180, -87.006734 * pi / 180, -29.827440 * pi / 180)
            },
        'tool_desc':
            {
                "pos": (-0.177341, 0.002327, 0.146822),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 旋转轴
    rotate_axis = (0, 0, 1)
    # 旋转角度
    rotate_angle = 10 * pi / 180
    # 旋转运动
    ret = libpyauboi5.move_rotate(rshd, user_coord, rotate_axis, rotate_angle)
    if ret == SUCC:
        print("rotate move succeeded.")
    else:
        print("rotate move failed.")


def rotate_move_on_tool():
    # 设置工具的运动学参数
    tool_desc = {"pos": (-0.177341, 0.002327, 0.146822),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    libpyauboi5.set_tool_kinematics_param(rshd, tool_desc)
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节运动的最大加速度
    joint_maxacc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxacc(rshd, joint_maxacc)
    # 设置关节运动的最大速度
    joint_maxvelc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_maxvelc)
    # 初始位置的关节角
    joint_radian = (173.108713 * pi / 180, -12.075005 * pi / 180, -83.663342 * pi / 180,
                    -15.641249 * pi / 180, -89.140000 * pi / 180, -28.328713 * pi / 180)
    # 轴动到初始位置
    ret = libpyauboi5.move_joint(rshd, joint_radian)
    if ret == SUCC:
        print("joint move to the initial position.")
        pass
    else:
        print("joint move failed.")
        print(ret)
        pass

    # 工具坐标系
    tool_coord = {
        'coord_type': 1,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point2": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point3": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            },
        'tool_desc':
            {
                "pos": (-0.177341, 0.002327, 0.146822),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 旋转轴
    rotate_axis = (1, 0, 0)
    # 旋转角度
    rotate_angle = 10 * pi / 180
    # 旋转运动
    ret = libpyauboi5.move_rotate(rshd, tool_coord, rotate_axis, rotate_angle)
    if ret == SUCC:
        print("rotate move succeeded.")
    else:
        print("rotate move failed.")
        print(ret)


def offline_move():
    # 添加离线轨迹文件
    ret = libpyauboi5.append_offline_track_file(rshd, "C:/orgin_data_2.txt")
    if ret != SUCC:
        print("添加离线轨迹文件失败。错误码：", ret)
    else:
        print("添加离线轨迹文件成功。")
    # 开始离线轨迹运动
    libpyauboi5.startup_offline_track(rshd)
    pass


def relative_move_on_base1():
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节型运动的最大速度和最大加速度
    joint_max_acc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    joint_max_velc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_max_velc)
    libpyauboi5.set_joint_maxacc(rshd, joint_max_acc)
    # 设置基坐标系下的偏移
    relative_pos = (0, 0, 0.01)
    relative_ori = (1, 0, 0, 0)
    ret = libpyauboi5.set_relative_offset_on_base(rshd, relative_pos, relative_ori)
    if ret != SUCC:
        print("设置偏移量失败。错误码：", ret)
    # 关节运动
    joint_radian = (173.108713 * pi / 180, -12.075005 * pi / 180, -83.663342 * pi / 180,
                    -15.641249 * pi / 180, -89.140000 * pi / 180, -28.328713 * pi / 180)
    libpyauboi5.move_joint(rshd, joint_radian)
    pass


def relative_move_on_base2():
    # 设置工具的运动学参数
    tool_desc = {
        "pos": (0.0, 0.0, 0.45),
        "ori": (1.0, 0.0, 0.0, 0.0)
    }
    libpyauboi5.set_tool_kinematics_param(rshd, tool_desc)
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节型运动的最大速度和最大加速度
    joint_max_acc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    joint_max_velc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_max_velc)
    libpyauboi5.set_joint_maxacc(rshd, joint_max_acc)
    # 设置基坐标系下的偏移
    relative_pos = (0, 0, 0.01)
    relative_ori = (1, 0, 0, 0)
    ret = libpyauboi5.set_relative_offset_on_base(rshd, relative_pos, relative_ori)
    if ret != SUCC:
        print("设置偏移量失败。错误码：", ret)
    # 关节运动
    joint_radian = (173.108713 * pi / 180, -12.075005 * pi / 180, -83.663342 * pi / 180,
                    -15.641249 * pi / 180, -89.140000 * pi / 180, -28.328713 * pi / 180)
    libpyauboi5.move_joint(rshd, joint_radian)
    pass


def relative_move_on_user1():
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节型运动的最大速度和最大加速度
    joint_max_acc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    joint_max_velc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_max_velc)
    libpyauboi5.set_joint_maxacc(rshd, joint_max_acc)
    # 设置用户坐标系下的偏移
    relative_pos = (0, 0, 0.01)
    relative_ori = (1, 0, 0, 0)
    user_coord = {
        'coord_type': 2,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (-75.093279 * pi / 180, 28.544643 * pi / 180, -114.313905 * pi / 180,
                           -62.769247 * pi / 180, -87.343517 * pi / 180, -27.888262 * pi / 180),
                "point2": (-89.239837 * pi / 180, 23.936171 * pi / 180, -122.299277 * pi / 180,
                           -65.208902 * pi / 180, -85.011123 * pi / 180, -41.87417 * pi / 180),
                "point3": (-77.059212 * pi / 180, 35.509518 * pi / 180, -101.108547 * pi / 180,
                           -56.433133 * pi / 180, -87.006734 * pi / 180, -29.827440 * pi / 180)
            },
        'tool_desc':
            {
                "pos": (0.0, 0.0, 0.45),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    ret = libpyauboi5.set_relative_offset_on_user(rshd, relative_pos, relative_ori, user_coord)
    if ret != SUCC:
        print("设置偏移量失败。错误码：", ret)
    # 关节运动
    joint_radian = (173.108713 * pi / 180, -12.075005 * pi / 180, -83.663342 * pi / 180,
                    -15.641249 * pi / 180, -89.140000 * pi / 180, -28.328713 * pi / 180)
    libpyauboi5.move_joint(rshd, joint_radian)
    pass


def relative_move_on_user2():
    # 设置工具的运动学参数
    tool_desc = {
        "pos": (0.0, 0.0, 0.45),
        "ori": (1.0, 0.0, 0.0, 0.0)
    }
    libpyauboi5.set_tool_kinematics_param(rshd, tool_desc)
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节型运动的最大速度和最大加速度
    joint_max_acc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    joint_max_velc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_max_velc)
    libpyauboi5.set_joint_maxacc(rshd, joint_max_acc)
    # 设置用户坐标系下的偏移
    relative_pos = (0, 0, 0.01)
    relative_ori = (1, 0, 0, 0)
    user_coord = {
        'coord_type': 2,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (-75.093279 * pi / 180, 28.544643 * pi / 180, -114.313905 * pi / 180,
                           -62.769247 * pi / 180, -87.343517 * pi / 180, -27.888262 * pi / 180),
                "point2": (-89.239837 * pi / 180, 23.936171 * pi / 180, -122.299277 * pi / 180,
                           -65.208902 * pi / 180, -85.011123 * pi / 180, -41.87417 * pi / 180),
                "point3": (-77.059212 * pi / 180, 35.509518 * pi / 180, -101.108547 * pi / 180,
                           -56.433133 * pi / 180, -87.006734 * pi / 180, -29.827440 * pi / 180)
            },
        'tool_desc':
            {
                "pos": (0.0, 0.0, 0.45),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    ret = libpyauboi5.set_relative_offset_on_user(rshd, relative_pos, relative_ori, user_coord)
    if ret != SUCC:
        print("设置偏移量失败。错误码：", ret)
    # 关节运动
    joint_radian = (173.108713 * pi / 180, -12.075005 * pi / 180, -83.663342 * pi / 180,
                    -15.641249 * pi / 180, -89.140000 * pi / 180, -28.328713 * pi / 180)
    libpyauboi5.move_joint(rshd, joint_radian)
    pass


def relative_move_on_tool():
    # 设置工具的运动学参数
    tool_desc = {
        "pos": (-0.177341, 0.002327, 0.146822),
        "ori": (1.0, 0.0, 0.0, 0.0)
    }
    libpyauboi5.set_tool_kinematics_param(rshd, tool_desc)
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节型运动的最大速度和最大加速度
    joint_max_acc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    joint_max_velc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_max_velc)
    libpyauboi5.set_joint_maxacc(rshd, joint_max_acc)
    # 设置用户坐标系下的偏移
    relative_pos = (0, 0, 0.01)
    relative_ori = (1, 0, 0, 0)
    user_coord = {
        'coord_type': 1,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point2": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point3": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            },
        'tool_desc':
            {
                "pos": (0.0, 0.0, 0.45),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    ret = libpyauboi5.set_relative_offset_on_user(rshd, relative_pos, relative_ori, user_coord)
    if ret != SUCC:
        print("设置偏移量失败。错误码：", ret)
    # 关节运动
    joint_radian = (173.108713 * pi / 180, -12.075005 * pi / 180, -83.663342 * pi / 180,
                    -15.641249 * pi / 180, -89.140000 * pi / 180, -28.328713 * pi / 180)
    libpyauboi5.move_joint(rshd, joint_radian)
    pass


def arrival_ahead():
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节运动的最大加速度
    joint_maxacc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxacc(rshd, joint_maxacc)
    # 设置关节运动的最大速度
    joint_maxvelc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_maxvelc)
    # 初始位置的关节角
    joint_radian = (173.108713 / 180 * pi, -12.075005 / 180 * pi, -83.663342 / 180 * pi,
                    -15.641249 / 180 * pi, -89.140000 / 180 * pi, -28.328713 / 180 * pi)
    # 轴动到初始位置
    ret = libpyauboi5.move_joint(rshd, joint_radian)
    if ret == SUCC:
        print("joint move to the initial position.")
        pass
    else:
        print("joint move failed.")
        print(ret)
        pass

    for i in range(5):
        if i % 2 == 0:
            # 设置提前到位的距离
            libpyauboi5.set_arrival_ahead_distance(rshd, 0.2)
        else:
            # 设置无提前到位
            libpyauboi5.set_no_arrival_ahead(rshd)
        # 关节运动1
        joint_radian = (20.0 / 180 * pi, 0.0 / 180 * pi, 90.0 / 180 * pi,
                        0.0 / 180 * pi, 90.0 / 180 * pi, 0.0 / 180 * pi)
        ret = libpyauboi5.move_joint(rshd, joint_radian)
        if ret != SUCC:
            print("关节运动1失败")
        # 关节运动2
        joint_radian = (50.0 / 180 * pi, 40.0 / 180 * pi, 78.0 / 180 * pi,
                        20.0 / 180 * pi, 66.0 / 180 * pi, 0.0 / 180 * pi)
        ret = libpyauboi5.move_joint(rshd, joint_radian)
        if ret != SUCC:
            print("关节运动2失败")


def track_move1():
    # 初始化全局运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节运动最大加速度
    joint_maxacc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxacc(rshd, joint_maxacc)
    # 设置关节运动最大速度
    joint_maxvelc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_maxvelc)
    # 设置末端运动最大线加速度
    line_maxacc = 0.5
    libpyauboi5.set_end_max_line_acc(rshd, line_maxacc)
    # 设置末端运动最大线速度
    line_maxvelc = 0.2
    libpyauboi5.set_end_max_line_velc(rshd, line_maxvelc)

    # 轴动到初始位置
    joint_radian = (-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008)
    ret = libpyauboi5.move_joint(rshd, joint_radian)
    if ret == SUCC:
        print("joint move to initial position.")
    else:
        print("joint move failed.")
    # 清除全局路点
    libpyauboi5.remove_all_waypoint(rshd)
    # 添加路点1
    joint_radian = (-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008)
    libpyauboi5.add_waypoint(rshd, joint_radian)
    # 添加路点2
    joint_radian = (-0.211675, -0.325189, -1.466753, 0.429232, -1.570794, -0.211680)
    libpyauboi5.add_waypoint(rshd, joint_radian)
    # 添加路点3
    joint_radian = (-0.037186, -0.224307, -1.398285, 0.396819, -1.570796, -0.037191)
    libpyauboi5.add_waypoint(rshd, joint_radian)
    # 设置圆运动圈数
    libpyauboi5.set_circular_loop_times(rshd, 0)
    # 圆弧运动
    ret = libpyauboi5.move_track(rshd, 2)
    if ret == SUCC:
        print("arc move succeeded.")
    else:
        print("arc move failed.")

    # 设置圆运动圈数
    libpyauboi5.set_circular_loop_times(rshd, 3)
    # 轴动到初始位置
    joint_radian = (-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008)
    ret = libpyauboi5.move_joint(rshd, joint_radian)
    if ret == SUCC:
        print("joint move to initial position.")
    else:
        print("joint move failed.")
    # 圆运动
    ret = libpyauboi5.move_track(rshd, 2)
    if ret == SUCC:
        print("circle move succeeded.")
    else:
        print("circle move failed.")

    # 设置交融半径
    libpyauboi5.set_blend_radius(rshd, 0.03)
    # 轴动到初始位置
    joint_radian = (-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008)
    ret = libpyauboi5.move_joint(rshd, joint_radian)
    if ret == SUCC:
        print("joint move to initial position.")
    else:
        print("joint move failed.")
    # MoveP运动
    ret = libpyauboi5.move_track(rshd, 3)
    if ret == SUCC:
        print("moveP succeeded.")
    else:
        print("moveP failed.")
    pass


def track_move2():
    # 初始化全局运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节运动最大加速度
    joint_maxacc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxacc(rshd, joint_maxacc)
    # 设置关节运动最大速度
    joint_maxvelc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_maxvelc)
    # 设置末端运动最大线加速度
    line_maxacc = 0.5
    libpyauboi5.set_end_max_line_acc(rshd, line_maxacc)
    # 设置末端运动最大线速度
    line_maxvelc = 0.2
    libpyauboi5.set_end_max_line_velc(rshd, line_maxvelc)

    # 轴动到初始位置
    joint_radian = (-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008)
    ret = libpyauboi5.move_joint(rshd, joint_radian)
    if ret == SUCC:
        print("joint move to initial position.")
    else:
        print("joint move failed.")
    # 清除全局路点
    libpyauboi5.remove_all_waypoint(rshd)
    # 添加路点1
    joint_radian = (-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008)
    libpyauboi5.add_waypoint(rshd, joint_radian)
    # 添加路点2
    joint_radian = (-0.211675, -0.325189, -1.466753, 0.429232, -1.570794, -0.211680)
    libpyauboi5.add_waypoint(rshd, joint_radian)
    # 添加路点3
    joint_radian = (-0.037186, -0.224307, -1.398285, 0.396819, -1.570796, -0.037191)
    libpyauboi5.add_waypoint(rshd, joint_radian)
    # 设置圆运动圈数
    libpyauboi5.set_circular_loop_times(rshd, 3)
    # 圆运动
    ret = libpyauboi5.move_track(rshd, 2)
    if ret == SUCC:
        print("circle move succeeded.")
    else:
        print("circle move failed.")


def track_move3():
    # 初始化全局运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节运动最大加速度
    joint_maxacc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxacc(rshd, joint_maxacc)
    # 设置关节运动最大速度
    joint_maxvelc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_maxvelc)
    # 设置末端运动最大线加速度
    line_maxacc = 0.5
    libpyauboi5.set_end_max_line_acc(rshd, line_maxacc)
    # 设置末端运动最大线速度
    line_maxvelc = 0.2
    libpyauboi5.set_end_max_line_velc(rshd, line_maxvelc)

    # 轴动到初始位置
    joint_radian = (-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008)
    ret = libpyauboi5.move_joint(rshd, joint_radian)
    if ret == SUCC:
        print("joint move to initial position.")
    else:
        print("joint move failed.")
    # 清除全局路点
    libpyauboi5.remove_all_waypoint(rshd)
    # 添加路点1
    joint_radian = (-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008)
    libpyauboi5.add_waypoint(rshd, joint_radian)
    # 添加路点2
    joint_radian = (-0.211675, -0.325189, -1.466753, 0.429232, -1.570794, -0.211680)
    libpyauboi5.add_waypoint(rshd, joint_radian)
    # 添加路点3
    joint_radian = (-0.037186, -0.224307, -1.398285, 0.396819, -1.570796, -0.037191)
    libpyauboi5.add_waypoint(rshd, joint_radian)
    # 设置交融半径
    libpyauboi5.set_blend_radius(rshd, 0.03)

    # MoveP运动
    ret = libpyauboi5.move_track(rshd, 3)
    if ret == SUCC:
        print("moveP succeeded.")
    else:
        print("moveP failed.")


def forward_inverse_kin():
    # 正解测试
    joint_radian = (-0.000003, -0.127267, -1.321122, 0.376934, -1.570796, -0.000008)
    fk = libpyauboi5.forward_kin(rshd, joint_radian)
    print(fk)
    # 逆解测试
    joint_radian = (0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000)
    ik = libpyauboi5.inverse_kin(rshd, joint_radian, fk['pos'], fk['ori'])
    print(ik)
    pass


def tcp2can_mode():
    # 进入TCP转CAN透传模式
    ret = libpyauboi5.enter_tcp2canbus_mode(rshd)
    if ret == SUCC:
        print("成功进入TCP转CAN透传模式")
    else:
        print("进入TCP转CAN透传模式失败")
    # 获取机械臂关节状态
    joint_status = libpyauboi5.get_joint_status(rshd)
    print("关节状态为：", joint_status)
    # 退出TCP转CAN透传模式
    libpyauboi5.leave_tcp2canbus_mode(rshd)
    pass


def coord_base2user1():
    # 法兰盘中心在基坐标系下的位置
    flange_center_pos_on_base = (-0.353894, -0.172828, 0.769021)
    # 法兰片中心在基坐标系下的姿态
    flange_center_rpy_on_base = (142.097809 * pi / 180, -27.216566 * pi / 180, -70.400696 * pi / 180)
    flange_center_ori_on_base = libpyauboi5.rpy_to_quaternion(rshd, flange_center_rpy_on_base)

    # 用户坐标系
    user_coord = {
        'coord_type': 2,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (87.349500 * pi / 180, -1.325605 * pi / 180, -100.570608 * pi / 180,
                           -38.767355 * pi / 180, -79.826347 * pi / 180, 30.554223 * pi / 180),
                "point2": (110.045221 * pi / 180, 9.913011 * pi / 180, -88.772795 * pi / 180,
                           -39.734154 * pi / 180, -91.385657 * pi / 180, 50.177824 * pi / 180),
                "point3": (86.846702 * pi / 180, -11.828697 * pi / 180, -109.736251 * pi / 180,
                           -37.350384 * pi / 180, -79.578889 * pi / 180, 30.109369 * pi / 180)
            },
        'tool_desc':
            {
                "pos": (0.0, 0.0, 0.45),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 工具描述
    tool_desc = {"pos": (0.0, 0.0, 0.45),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # 工具在用户坐标系下的位置和姿态
    tool_on_user = libpyauboi5.base_to_user(rshd, flange_center_pos_on_base, flange_center_ori_on_base,
                                            user_coord, tool_desc)
    print("pos: ", tool_on_user["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, tool_on_user["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)
    pass


def coord_base2user2():
    # 法兰盘中心在基坐标系下的位置
    flange_center_pos_on_base = (-0.260306, 0.568384, 0.082322)
    # 法兰片中心在基坐标系下的姿态
    flange_center_rpy_on_base = (170.001663 * pi / 180, 2.301093 * pi / 180, -137.175964 * pi / 180)
    flange_center_ori_on_base = libpyauboi5.rpy_to_quaternion(rshd, flange_center_rpy_on_base)
    # 用户坐标系
    user_coord = {
        'coord_type': 2,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (-75.093279 * pi / 180, 28.544643 * pi / 180, -114.313905 * pi / 180,
                           -62.769247 * pi / 180, -87.343517 * pi / 180, -27.888262 * pi / 180),
                "point2": (-89.239837 * pi / 180, 23.936171 * pi / 180, -122.299277 * pi / 180,
                           -65.208902 * pi / 180, -85.011123 * pi / 180, -41.87417 * pi / 180),
                "point3": (-77.059212 * pi / 180, 35.509518 * pi / 180, -101.108547 * pi / 180,
                           -56.433133 * pi / 180, -87.006734 * pi / 180, -29.827440 * pi / 180)
            },
        'tool_desc':
            {
                "pos": (0.0, 0.0, 0.45),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 工具描述
    tool_desc = {"pos": (0.0, 0.0, 0.0),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # 法兰盘中心在用户坐标系下的位置和姿态
    flange_center_on_user = libpyauboi5.base_to_user(rshd, flange_center_pos_on_base, flange_center_ori_on_base,
                                                     user_coord, tool_desc)
    print("pos: ", flange_center_on_user["pos"])
    flange_center_rpy = libpyauboi5.quaternion_to_rpy(rshd, flange_center_on_user["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    flange_center_rpy = np.array(flange_center_rpy) * 180 / pi
    print("rpy: ", flange_center_rpy)
    pass


def coord_base2user3():
    # 法兰盘中心在基坐标系下的位置
    flange_center_pos_on_base = (0.038457, -0.412663, 0.696753)
    # 法兰片中心在基坐标系下的姿态
    flange_center_rpy_on_base = (158.025070 * pi / 180, -22.521408 * pi / 180, -13.243414 * pi / 180)
    flange_center_ori_on_base = libpyauboi5.rpy_to_quaternion(rshd, flange_center_rpy_on_base)
    # 基坐标系
    base_coord = {'coord_type': 2,
                  'calibrate_method': 0,
                  'calibrate_points':
                      {"point1": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                       "point2": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                       "point3": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)},
                  'tool_desc':
                      {"pos": (0.0, 0.0, 0.0),
                       "ori": (1.0, 0.0, 0.0, 0.0)}
                  }
    # 工具描述
    tool_desc = {"pos": (0.10, 0.05, 0.15),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # 工具在基坐标系下的位置和姿态
    tool_on_base = libpyauboi5.base_to_user(rshd, flange_center_pos_on_base, flange_center_ori_on_base,
                                            base_coord, tool_desc)
    print("pos: ", tool_on_base["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, tool_on_base["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)
    pass


def coord_user2base1():
    # 工具末端在用户坐标系下的位置
    tool_pos_on_base = (-0.119977, -0.001744, 0.074654)
    # 工具末端在用户坐标系下的姿态
    tool_rpy_on_base = (171.337570 * pi / 180, 1.297959 * pi / 180, -129.826096 * pi / 180)
    tool_ori_on_base = libpyauboi5.rpy_to_quaternion(rshd, tool_rpy_on_base)
    # 用户坐标系
    user_coord = {
        'coord_type': 2,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (-75.093279 * pi / 180, 28.544643 * pi / 180, -114.313905 * pi / 180,
                           -62.769247 * pi / 180, -87.343517 * pi / 180, -27.888262 * pi / 180),
                "point2": (-89.239837 * pi / 180, 23.936171 * pi / 180, -122.299277 * pi / 180,
                           -65.208902 * pi / 180, -85.011123 * pi / 180, -41.87417 * pi / 180),
                "point3": (-77.059212 * pi / 180, 35.509518 * pi / 180, -101.108547 * pi / 180,
                           -56.433133 * pi / 180, -87.006734 * pi / 180, -29.827440 * pi / 180)
            },
        'tool_desc':
            {
                "pos": (0.0, 0.0, 0.45),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 工具描述
    tool_desc = {"pos": (0.0, 0.0, 0.45),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # 法兰盘中心在基坐标系下的位置和姿态
    flange_center_on_base = libpyauboi5.user_to_base(rshd, tool_pos_on_base, tool_ori_on_base,
                                                     user_coord, tool_desc)
    print("pos: ", flange_center_on_base["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, flange_center_on_base["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)
    pass


def coord_user2base2():
    # 法兰盘中心在用户坐标系下的位置
    flange_center_pos_on_user = (-0.074378, -0.052889, 0.519407)
    # 法兰盘中心在用户坐标系下的姿态
    flange_center_rpy_on_user = (171.337570 * pi / 180, 1.297959 * pi / 180, -129.826096 * pi / 180)
    flange_center_ori_on_user = libpyauboi5.rpy_to_quaternion(rshd, flange_center_rpy_on_user)
    # 用户坐标系
    user_coord = {
        'coord_type': 2,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (-75.093279 * pi / 180, 28.544643 * pi / 180, -114.313905 * pi / 180,
                           -62.769247 * pi / 180, -87.343517 * pi / 180, -27.888262 * pi / 180),
                "point2": (-89.239837 * pi / 180, 23.936171 * pi / 180, -122.299277 * pi / 180,
                           -65.208902 * pi / 180, -85.011123 * pi / 180, -41.87417 * pi / 180),
                "point3": (-77.059212 * pi / 180, 35.509518 * pi / 180, -101.108547 * pi / 180,
                           -56.433133 * pi / 180, -87.006734 * pi / 180, -29.827440 * pi / 180)
            },
        'tool_desc':
            {
                "pos": (0.0, 0.0, 0.45),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 工具描述
    tool_desc = {"pos": (0.0, 0.0, 0.0),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # 法兰盘中心在基坐标系下的位置和姿态
    flange_center_on_base = libpyauboi5.user_to_base(rshd, flange_center_pos_on_user, flange_center_ori_on_user,
                                                     user_coord, tool_desc)
    print("pos: ", flange_center_on_base["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, flange_center_on_base["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)
    pass


def coord_user2base3():
    # 工具末端在基坐标系下的位置
    tool_pos_on_base = (-0.420340, 0.556251, -0.285832)
    # 工具末端在基坐标系下的姿态
    tool_rpy_on_base = (171.337570 * pi / 180, 1.297173 * pi / 180, -129.826294 * pi / 180)
    tool_ori_on_base = libpyauboi5.rpy_to_quaternion(rshd, tool_rpy_on_base)
    # 基坐标系
    base_coord = {
        'coord_type': 0,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point2": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point3": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            },
        'tool_desc':
            {
                "pos": (0.0, 0.0, 0.0),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 工具描述
    tool_desc = {"pos": (0.0, 0.0, 0.45),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # 法兰盘中心在基坐标系下的位置和姿态
    flange_center_on_base = libpyauboi5.user_to_base(rshd, tool_pos_on_base, tool_ori_on_base,
                                                     base_coord, tool_desc)
    print("pos: ", flange_center_on_base["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, flange_center_on_base["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)
    pass


def coord_base2base():
    # 法兰盘中心在基坐标系下的位置
    flange_center_pos_on_base = (-0.400319, -0.121499, 0.547598)
    # 法兰片中心在基坐标系下的姿态
    flange_center_rpy_on_base = (179.999588 * pi / 180, -0.000081 * pi / 180, -89.999641 * pi / 180)
    flange_center_ori_on_base = libpyauboi5.rpy_to_quaternion(rshd, flange_center_rpy_on_base)
    # 工具描述
    tool_desc = {"pos": (0.0, 0.0, 0.45),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # 工具在基坐标系下的位置和姿态
    tool_on_base = libpyauboi5.base_to_base_additional_tool(rshd, flange_center_pos_on_base,
                                                            flange_center_ori_on_base, tool_desc)
    print("pos: ", tool_on_base["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, tool_on_base["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)
    pass


def robot_parameters():
    # 设置末端工具参数
    tool_desc = {
        "pos": (0.0, 0.0, 0.45),
        "ori": (1.0, 0.0, 0.0, 0.0)
    }
    ret = libpyauboi5.set_tool_end_param(rshd, tool_desc)
    if ret != SUCC:
        print("设置末端工具参数失败。错误码： ", ret)

    # 设置无工具的动力学参数
    libpyauboi5.set_none_tool_dynamics_param(rshd)

    # 设置工具的动力学参数
    tool_dynamics = {
        "position": (0.0, 0.0, 0.0),
        "payload": 1.0,
        "inertia": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    }
    libpyauboi5.set_tool_dynamics_param(rshd, tool_dynamics)

    # 获取末端工具参数
    tool_desc = libpyauboi5.get_tool_dynamics_param(rshd)
    print("获取末端工具参数： ", tool_desc)

    # 设置无工具运动学参数　
    libpyauboi5.set_none_tool_kinematics_param(rshd)

    # 设置工具的运动学参数
    tool_desc = {
        "pos": (0.0, 0.0, 0.45),
        "ori": (1.0, 0.0, 0.0, 0.0)
    }
    libpyauboi5.set_tool_kinematics_param(rshd, tool_desc)

    # 获取工具的运动学参数
    tool_desc = libpyauboi5.get_tool_kinematics_param(rshd)
    print("工具的运动学参数： ", tool_desc)

    # 设置机械臂服务器工作模式
    libpyauboi5.set_work_mode(rshd, 1)

    # 获取机械臂服务器当前工作模式
    work_mode = libpyauboi5.get_work_mode(rshd)
    print("机械臂服务器当前的工作模式： ", work_mode)

    # 设置机械臂碰撞等级
    collision_class = 7
    libpyauboi5.set_collision_class(rshd, collision_class)

    # 获取当前是否已经链接真实机械臂
    ret = libpyauboi5.is_have_real_robot(rshd)
    print("是否存在真实机械臂： ", ret)

    # 当前机械臂是否运行在联机模式
    ret = libpyauboi5.is_online_mode(rshd)
    print("是否在联机模式： ", ret)

    # 当前机械臂是否运行在联机主模式
    ret = libpyauboi5.is_online_master_mode(rshd)
    print("是否在联机主模式： ", ret)

    # 获取机械臂当前状态信息
    joint_status = libpyauboi5.get_joint_status(rshd)
    print("获取当前状态信息： ", joint_status)

    # 获取机械臂当前位置信息
    current_waypoint = libpyauboi5.get_current_waypoint(rshd)
    print("获取当前的位置信息： ", current_waypoint)
    pass


def reduce_mode():
    # 退出缩减模式
    libpyauboi5.exit_reduce_mode(rshd)
    # 进入缩减模式
    ret = libpyauboi5.enter_reduce_mode(rshd)
    if ret != SUCC:
        print("进入缩减模式失败。错误号为： ", ret)
    else:
        print("进入缩减模式")
    # 初始化运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节运动的最大加速度和最大速度
    joint_max_acc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    joint_max_velc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxacc(rshd, joint_max_acc)
    libpyauboi5.set_joint_maxvelc(rshd, joint_max_velc)
    # 关节运动
    joint_radian = (60.443151 * pi / 180, 42.275463 * pi / 180, -97.679737 * pi / 180,
                    -49.990510 * pi / 180, -90.007372 * pi / 180, 62.567046 * pi / 180)
    libpyauboi5.move_joint(rshd, joint_radian)
    # 退出缩减模式
    libpyauboi5.exit_reduce_mode(rshd)
    pass


def board_io():
    # 设置IO状态
    io_type = 4
    io_name = "U_DI_00"
    io_value = 1
    libpyauboi5.set_board_io_status(rshd, io_type, io_name, io_value)

    # 获取IO状态
    io_type = 4
    io_name = "U_DI_00"
    board_io_status = libpyauboi5.get_board_io_status(rshd, io_type, io_name)
    print("获取IO状态： ", board_io_status)

    # 获取IO配置
    io_type = 5
    board_io_config = libpyauboi5.get_board_io_config(rshd, io_type)
    print("获取IO配置： ", board_io_config)


def tool_io():
    # 设置工具端电源类型
    libpyauboi5.set_tool_power_type(rshd, 0)

    # 获取工具端电源类型
    tool_power_type = libpyauboi5.get_tool_power_type(rshd)
    print("获取工具端电源类型： ", tool_power_type)

    # 设置工具端数字IO类型
    io_addr = 0
    io_type = 1
    libpyauboi5.set_tool_io_type(rshd, io_type, io_addr)

    # 获取工具端电压数值
    tool_power_voltage = libpyauboi5.get_tool_power_voltage(rshd)
    print("获取工具端电压数值： ", tool_power_voltage)

    # 设置工具端IO状态
    io_name = "T_DI/O_00"
    io_status = 0
    libpyauboi5.set_tool_do_status(rshd, io_name, io_status)

    # 获取工具端IO状态
    tool_io_name = "T_DI/O_00"
    tool_io_status = libpyauboi5.get_tool_io_status(rshd, tool_io_name)
    print("获取工具端IO状态： ", tool_io_status)


def test_get_current_waypoint():
    # 当前路点信息
    current_waypoint = libpyauboi5.get_current_waypoint(rshd)
    joint = np.array(current_waypoint["joint"]) / pi * 180
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    rpy = libpyauboi5.quaternion_to_rpy(rshd, current_waypoint["ori"])
    rpy = np.array(rpy) * 180 / pi
    print("在笛卡尔坐标系下的当前路点：")
    print("关节角： ", joint)
    print("位置： ", current_waypoint["pos"])
    print("欧拉角： ", rpy)
    pass


def to_initial_pos():
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节运动的最大加速度
    joint_maxacc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxacc(rshd, joint_maxacc)
    # 设置关节运动的最大速度
    joint_maxvelc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_maxvelc)
    # 初始路点的关节角
    joint_radian = (
        73.05 * pi / 180, -5.45 * pi / 180, -57.00 * pi / 180, 16.20 * pi / 180, -67.75 * pi / 180, 5.15 * pi / 180)
    # 轴动到初始位置
    ret = libpyauboi5.move_joint(rshd, joint_radian)
    if ret == SUCC:
        print("joint move to the initial position.")
    else:
        print("joint move failed.")
        print(ret)
    pass


# 测试flange_center在基坐标系下转tool在用户坐标系
def test_base_user1():
    # 轴动到初始位置
    to_initial_pos()

    # 获取当前在Base坐标系下的的路点信息
    test_get_current_waypoint()
    current_waypoint = libpyauboi5.get_current_waypoint(rshd)
    flange_center_pos_on_base = current_waypoint["pos"]
    flange_center_ori_on_base = current_waypoint["ori"]

    # 用户坐标系
    user_coord = {
        'coord_type': 2,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (87.349500 * pi / 180, -1.325605 * pi / 180, -100.570608 * pi / 180,
                           -38.767355 * pi / 180, -79.826347 * pi / 180, 30.554223 * pi / 180),
                "point2": (110.045221 * pi / 180, 9.913011 * pi / 180, -88.772795 * pi / 180,
                           -39.734154 * pi / 180, -91.385657 * pi / 180, 50.177824 * pi / 180),
                "point3": (86.846702 * pi / 180, -11.828697 * pi / 180, -109.736251 * pi / 180,
                           -37.350384 * pi / 180, -79.578889 * pi / 180, 30.109369 * pi / 180)
            },
        'tool_desc':
            {
                "pos": (0.10, 0.05, 0.15),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 工具描述
    tool_desc = {"pos": (0.10, 0.05, 0.15),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # 工具在用户坐标系下的位置和姿态
    print("工具在用户坐标系下的位置和姿态：")
    tool_on_user = libpyauboi5.base_to_user(rshd, flange_center_pos_on_base, flange_center_ori_on_base,
                                            user_coord, tool_desc)
    print("pos: ", tool_on_user["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, tool_on_user["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)

    # 工具末端在用户坐标系下的位置
    tool_pos_on_base = tool_on_user["pos"]
    # 工具末端在用户坐标系下的姿态
    tool_ori_on_base = tool_on_user["ori"]
    # 法兰盘中心在基坐标系下的位置和姿态
    print("法兰盘中心在基坐标系下的位置姿态： ")
    flange_center_on_base = libpyauboi5.user_to_base(rshd, tool_pos_on_base, tool_ori_on_base,
                                                     user_coord, tool_desc)
    print("pos: ", flange_center_on_base["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, flange_center_on_base["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)
    pass


def test_base_base():
    # 轴动到初始位置
    to_initial_pos()
    # 获取当前在Base坐标系下的的路点信息
    test_get_current_waypoint()
    current_waypoint = libpyauboi5.get_current_waypoint(rshd)
    flange_center_pos_on_base = current_waypoint["pos"]
    flange_center_ori_on_base = current_waypoint["ori"]
    # 工具描述
    tool_desc = {"pos": (0.10, 0.05, 0.15),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # 工具在基坐标系下的位置和姿态
    print("工具在基坐标系下的位置和姿态：")
    tool_on_base = libpyauboi5.base_to_base_additional_tool(rshd, flange_center_pos_on_base,
                                                            flange_center_ori_on_base, tool_desc)
    print("pos: ", tool_on_base["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, tool_on_base["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)

    # 工具末端在基坐标系下的位置
    tool_pos_on_base = tool_on_base["pos"]
    # 工具末端在基坐标系下的姿态
    tool_ori_on_base = tool_on_base["ori"]
    # 基坐标系
    base_coord = {
        'coord_type': 0,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point2": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point3": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            },
        'tool_desc':
            {
                "pos": (0.0, 0.0, 0.0),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 法兰盘中心在基坐标系下的位置和姿态
    print("法兰盘中心在基坐标系下的位置和姿态: ")
    flange_center_on_base = libpyauboi5.user_to_base(rshd, tool_pos_on_base, tool_ori_on_base,
                                                     base_coord, tool_desc)
    print("pos: ", flange_center_on_base["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, flange_center_on_base["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)
    pass


def test_base_user2():
    # 轴动到初始位置
    to_initial_pos()

    # 获取当前在Base坐标系下的的路点信息
    test_get_current_waypoint()
    current_waypoint = libpyauboi5.get_current_waypoint(rshd)
    flange_center_pos_on_base = current_waypoint["pos"]
    flange_center_ori_on_base = current_waypoint["ori"]

    # 用户坐标系
    user_coord = {
        'coord_type': 2,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (87.349500 * pi / 180, -1.325605 * pi / 180, -100.570608 * pi / 180,
                           -38.767355 * pi / 180, -79.826347 * pi / 180, 30.554223 * pi / 180),
                "point2": (110.045221 * pi / 180, 9.913011 * pi / 180, -88.772795 * pi / 180,
                           -39.734154 * pi / 180, -91.385657 * pi / 180, 50.177824 * pi / 180),
                "point3": (86.846702 * pi / 180, -11.828697 * pi / 180, -109.736251 * pi / 180,
                           -37.350384 * pi / 180, -79.578889 * pi / 180, 30.109369 * pi / 180)
            },
        'tool_desc':
            {
                "pos": (0.10, 0.05, 0.15),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 工具描述
    tool_desc = {"pos": (0.0, 0.0, 0.0),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # flange_center在用户坐标系下的位置和姿态
    print("法兰盘中心在用户坐标系下的位置和姿态：")
    flange_on_user = libpyauboi5.base_to_user(rshd, flange_center_pos_on_base, flange_center_ori_on_base,
                                              user_coord, tool_desc)
    print("pos: ", flange_on_user["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, flange_on_user["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)

    # 法兰盘中心在用户坐标系下的位置
    flange_center_pos_on_user = flange_on_user["pos"]
    # 法兰盘中心在用户坐标系下的姿态
    flange_center_ori_on_user = flange_on_user["ori"]
    # 工具描述
    tool_desc = {"pos": (0.0, 0.0, 0.0),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # 法兰盘中心在基坐标系下的位置和姿态
    print("法兰盘中心在基坐标系下的位置和姿态: ")
    flange_center_on_base = libpyauboi5.user_to_base(rshd, flange_center_pos_on_user, flange_center_ori_on_user,
                                                     user_coord, tool_desc)
    print("pos: ", flange_center_on_base["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, flange_center_on_base["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)
    pass


# 测试——旋转运动1：法兰盘中心在基坐标系下的旋转
def test_rotate_move1():
    # 轴动到初始位置
    to_initial_pos()

    # 基坐标系
    base_coord = {
        'coord_type': 0,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point2": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point3": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            },
        'tool_desc':
            {
                "pos": (0.0, 0.0, 0.0),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 旋转轴
    rotate_axis = (1, 0, 0)
    # 旋转角度
    rotate_angle = -5 * pi / 180
    # 旋转运动
    ret = libpyauboi5.move_rotate(rshd, base_coord, rotate_axis, rotate_angle)
    if ret == SUCC:
        print("rotate move succeeded.")
    else:
        print("rotate move failed.")

    test_get_current_waypoint()
    pass


# 测试——旋转运动2：工具末端在基坐标系下的旋转
def test_rotate_move2():
    to_initial_pos()
    # 设置工具的运动学参数
    tool_desc = {"pos": (0.1, 0.05, 0.15),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    libpyauboi5.set_tool_kinematics_param(rshd, tool_desc)

    # 基坐标系
    base_coord = {
        'coord_type': 0,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point2": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point3": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            },
        'tool_desc':
            {
                "pos": (0.0, 0.0, 0.0),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 旋转轴
    rotate_axis = (1, 0, 0)
    # 旋转角度
    rotate_angle = -5 * pi / 180
    # 旋转运动
    ret = libpyauboi5.move_rotate(rshd, base_coord, rotate_axis, rotate_angle)
    if ret == SUCC:
        print("rotate move succeeded.")
    else:
        print("rotate move failed.")

    # 获取当前在Base坐标系下的的路点信息
    test_get_current_waypoint()
    current_waypoint = libpyauboi5.get_current_waypoint(rshd)
    flange_center_pos_on_base = current_waypoint["pos"]
    flange_center_ori_on_base = current_waypoint["ori"]
    # 工具描述
    tool_desc = {"pos": (0.10, 0.05, 0.15),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # 工具在基坐标系下的位置和姿态
    print("工具在基坐标系下的位置和姿态：")
    tool_on_base = libpyauboi5.base_to_base_additional_tool(rshd, flange_center_pos_on_base,
                                                            flange_center_ori_on_base, tool_desc)
    print("pos: ", tool_on_base["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, tool_on_base["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)


# 测试——旋转运动：法兰盘中心在用户坐标系下的旋转
def test_rotate_move3():
    to_initial_pos()

    # 用户坐标系
    user_coord = {
        'coord_type': 2,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (87.349500 * pi / 180, -1.325605 * pi / 180, -100.570608 * pi / 180,
                           -38.767355 * pi / 180, -79.826347 * pi / 180, 30.554223 * pi / 180),
                "point2": (110.045221 * pi / 180, 9.913011 * pi / 180, -88.772795 * pi / 180,
                           -39.734154 * pi / 180, -91.385657 * pi / 180, 50.177824 * pi / 180),
                "point3": (86.846702 * pi / 180, -11.828697 * pi / 180, -109.736251 * pi / 180,
                           -37.350384 * pi / 180, -79.578889 * pi / 180, 30.109369 * pi / 180)
            },
        'tool_desc':
            {
                "pos": (0.10, 0.05, 0.15),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 旋转轴
    rotate_axis = (1, 0, 0)
    # 旋转角度
    rotate_angle = -5 * pi / 180
    # 旋转运动
    ret = libpyauboi5.move_rotate(rshd, user_coord, rotate_axis, rotate_angle)
    if ret == SUCC:
        print("rotate move succeeded.")
    else:
        print("rotate move failed.")
    # 获取当前在Base坐标系下的的路点信息
    test_get_current_waypoint()
    current_waypoint = libpyauboi5.get_current_waypoint(rshd)
    flange_center_pos_on_base = current_waypoint["pos"]
    flange_center_ori_on_base = current_waypoint["ori"]

    # 工具描述
    tool_desc = {"pos": (0.0, 0.0, 0.0),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # flange_center在用户坐标系下的位置和姿态
    print("法兰盘中心在用户坐标系下的位置和姿态：")
    flange_on_user = libpyauboi5.base_to_user(rshd, flange_center_pos_on_base, flange_center_ori_on_base,
                                              user_coord, tool_desc)
    print("pos: ", flange_on_user["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, flange_on_user["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)


# 测试——旋转运动：工具末端在用户坐标系下的旋转
def test_rotate_move4():
    to_initial_pos()
    # 设置工具的运动学参数
    tool_desc = {"pos": (0.10, 0.05, 0.15),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    libpyauboi5.set_tool_kinematics_param(rshd, tool_desc)

    # 用户坐标系
    user_coord = {
        'coord_type': 2,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (87.349500 * pi / 180, -1.325605 * pi / 180, -100.570608 * pi / 180,
                           -38.767355 * pi / 180, -79.826347 * pi / 180, 30.554223 * pi / 180),
                "point2": (110.045221 * pi / 180, 9.913011 * pi / 180, -88.772795 * pi / 180,
                           -39.734154 * pi / 180, -91.385657 * pi / 180, 50.177824 * pi / 180),
                "point3": (86.846702 * pi / 180, -11.828697 * pi / 180, -109.736251 * pi / 180,
                           -37.350384 * pi / 180, -79.578889 * pi / 180, 30.109369 * pi / 180)
            },
        'tool_desc':
            {
                "pos": (0.10, 0.05, 0.15),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 旋转轴
    rotate_axis = (1, 0, 0)
    # 旋转角度
    rotate_angle = 5 * pi / 180
    # 旋转运动
    ret = libpyauboi5.move_rotate(rshd, user_coord, rotate_axis, rotate_angle)
    if ret == SUCC:
        print("rotate move succeeded.")
    else:
        print("rotate move failed.")
    # 获取当前在Base坐标系下的的路点信息
    test_get_current_waypoint()
    current_waypoint = libpyauboi5.get_current_waypoint(rshd)
    flange_center_pos_on_base = current_waypoint["pos"]
    flange_center_ori_on_base = current_waypoint["ori"]

    # 工具描述
    tool_desc = {"pos": (0.10, 0.05, 0.15),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # 工具在用户坐标系下的位置和姿态
    print("工具在用户坐标系下的位置和姿态：")
    tool_on_user = libpyauboi5.base_to_user(rshd, flange_center_pos_on_base, flange_center_ori_on_base,
                                            user_coord, tool_desc)
    print("pos: ", tool_on_user["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, tool_on_user["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)


# 测试——旋转运动：工具坐标系下的旋转
def test_rotate_move5():
    to_initial_pos()
    # 设置工具的运动学参数
    tool_desc = {"pos": (0.10, 0.05, 0.15),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    libpyauboi5.set_tool_kinematics_param(rshd, tool_desc)

    # 工具坐标系
    tool_coord = {
        'coord_type': 1,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point2": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point3": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            },
        'tool_desc':
            {
                "pos": (0.10, 0.05, 0.15),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    # 旋转轴
    rotate_axis = (1, 0, 0)
    # 旋转角度
    rotate_angle = -5 * pi / 180
    # 旋转运动
    ret = libpyauboi5.move_rotate(rshd, tool_coord, rotate_axis, rotate_angle)
    if ret == SUCC:
        print("rotate move succeeded.")
    else:
        print("rotate move failed.")
        print(ret)
    test_get_current_waypoint()


# 测试——偏移运动：法兰盘中心在基坐标系下的偏移运动
def test_relative_move_on_base1():
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节型运动的最大速度和最大加速度
    joint_max_acc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    joint_max_velc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_max_velc)
    libpyauboi5.set_joint_maxacc(rshd, joint_max_acc)
    # 设置基坐标系下的偏移
    relative_pos = (0, 0, 0)
    relative_rpy = (-5 / 180 * pi, 0, 0)
    relative_ori = libpyauboi5.rpy_to_quaternion(rshd, relative_rpy)
    # relative_ori = (1, 0, 0, 0)
    ret = libpyauboi5.set_relative_offset_on_base(rshd, relative_pos, relative_ori)
    if ret != SUCC:
        print("设置偏移量失败。错误码：", ret)
    # 关节运动
    joint_radian = (73.05 * pi / 180, -5.45 * pi / 180, -57.00 * pi / 180,
                    16.20 * pi / 180, -67.75 * pi / 180, 5.15 * pi / 180)
    libpyauboi5.move_joint(rshd, joint_radian)
    # 获取在基坐标系下的路点
    test_get_current_waypoint()
    pass


# 测试——偏移运动：工具末端在基坐标系下的偏移运动
def test_relative_move_on_base2():
    # 设置工具的运动学参数
    tool_desc = {
        "pos": (0.10, 0.05, 0.15),
        "ori": (1.0, 0.0, 0.0, 0.0)
    }
    libpyauboi5.set_tool_kinematics_param(rshd, tool_desc)
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节型运动的最大速度和最大加速度
    joint_max_acc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    joint_max_velc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_max_velc)
    libpyauboi5.set_joint_maxacc(rshd, joint_max_acc)
    # 设置基坐标系下的偏移
    relative_pos = (0, 0, 0)
    relative_rpy = (0, 0, 5 / 180 * pi)
    relative_ori = libpyauboi5.rpy_to_quaternion(rshd, relative_rpy)
    # relative_ori = (1, 0, 0, 0)
    ret = libpyauboi5.set_relative_offset_on_base(rshd, relative_pos, relative_ori)
    ret = libpyauboi5.set_relative_offset_on_base(rshd, relative_pos, relative_ori)
    if ret != SUCC:
        print("设置偏移量失败。错误码：", ret)
    # 关节运动
    joint_radian = (73.05 * pi / 180, -5.45 * pi / 180, -57.00 * pi / 180,
                    16.20 * pi / 180, -67.75 * pi / 180, 5.15 * pi / 180)
    libpyauboi5.move_joint(rshd, joint_radian)

    # 获取当前在Base坐标系下的的路点信息
    test_get_current_waypoint()
    current_waypoint = libpyauboi5.get_current_waypoint(rshd)
    flange_center_pos_on_base = current_waypoint["pos"]
    flange_center_ori_on_base = current_waypoint["ori"]
    # 工具描述
    tool_desc = {"pos": (0.10, 0.05, 0.15),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # 工具在基坐标系下的位置和姿态
    print("工具在基坐标系下的位置和姿态：")
    tool_on_base = libpyauboi5.base_to_base_additional_tool(rshd, flange_center_pos_on_base,
                                                            flange_center_ori_on_base, tool_desc)
    print("pos: ", tool_on_base["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, tool_on_base["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)
    pass


# 测试——偏移运动：法兰盘中心在用户坐标系下的偏移运动
def test_relative_move_on_user1():
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节型运动的最大速度和最大加速度
    joint_max_acc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    joint_max_velc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_max_velc)
    libpyauboi5.set_joint_maxacc(rshd, joint_max_acc)
    # 设置用户坐标系下的偏移
    relative_pos = (0, 0, 0)
    relative_rpy = (0, 0, -5 / 180 * pi)
    relative_ori = libpyauboi5.rpy_to_quaternion(rshd, relative_rpy)
    # 用户坐标系
    user_coord = {
        'coord_type': 2,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (87.349500 * pi / 180, -1.325605 * pi / 180, -100.570608 * pi / 180,
                           -38.767355 * pi / 180, -79.826347 * pi / 180, 30.554223 * pi / 180),
                "point2": (110.045221 * pi / 180, 9.913011 * pi / 180, -88.772795 * pi / 180,
                           -39.734154 * pi / 180, -91.385657 * pi / 180, 50.177824 * pi / 180),
                "point3": (86.846702 * pi / 180, -11.828697 * pi / 180, -109.736251 * pi / 180,
                           -37.350384 * pi / 180, -79.578889 * pi / 180, 30.109369 * pi / 180)
            },
        'tool_desc':
            {
                "pos": (0.10, 0.05, 0.15),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    ret = libpyauboi5.set_relative_offset_on_user(rshd, relative_pos, relative_ori, user_coord)
    if ret != SUCC:
        print("设置偏移量失败。错误码：", ret)
    # 关节运动
    joint_radian = (73.05 * pi / 180, -5.45 * pi / 180, -57.00 * pi / 180,
                    16.20 * pi / 180, -67.75 * pi / 180, 5.15 * pi / 180)
    libpyauboi5.move_joint(rshd, joint_radian)

    # 获取当前在Base坐标系下的的路点信息
    test_get_current_waypoint()
    current_waypoint = libpyauboi5.get_current_waypoint(rshd)
    flange_center_pos_on_base = current_waypoint["pos"]
    flange_center_ori_on_base = current_waypoint["ori"]
    # 工具描述
    tool_desc = {"pos": (0.0, 0.0, 0.0),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # flange_center在用户坐标系下的位置和姿态
    print("法兰盘中心在用户坐标系下的位置和姿态：")
    flange_on_user = libpyauboi5.base_to_user(rshd, flange_center_pos_on_base, flange_center_ori_on_base,
                                              user_coord, tool_desc)
    print("pos: ", flange_on_user["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, flange_on_user["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)
    pass


# 测试——偏移运动：工具末端在用户坐标系下的偏移运动
def test_relative_move_on_user2():
    # 设置工具的运动学参数
    tool_desc = {
        "pos": (0.10, 0.05, 0.15),
        "ori": (1.0, 0.0, 0.0, 0.0)
    }
    libpyauboi5.set_tool_kinematics_param(rshd, tool_desc)
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节型运动的最大速度和最大加速度
    joint_max_acc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    joint_max_velc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_max_velc)
    libpyauboi5.set_joint_maxacc(rshd, joint_max_acc)
    # 设置用户坐标系下的偏移
    relative_pos = (0, 0, 0)
    relative_rpy = (0, 0, -5 / 180 * pi)
    relative_ori = libpyauboi5.rpy_to_quaternion(rshd, relative_rpy)
    # 用户坐标系
    user_coord = {
        'coord_type': 2,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (87.349500 * pi / 180, -1.325605 * pi / 180, -100.570608 * pi / 180,
                           -38.767355 * pi / 180, -79.826347 * pi / 180, 30.554223 * pi / 180),
                "point2": (110.045221 * pi / 180, 9.913011 * pi / 180, -88.772795 * pi / 180,
                           -39.734154 * pi / 180, -91.385657 * pi / 180, 50.177824 * pi / 180),
                "point3": (86.846702 * pi / 180, -11.828697 * pi / 180, -109.736251 * pi / 180,
                           -37.350384 * pi / 180, -79.578889 * pi / 180, 30.109369 * pi / 180)
            },
        'tool_desc':
            {
                "pos": (0.10, 0.05, 0.15),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    ret = libpyauboi5.set_relative_offset_on_user(rshd, relative_pos, relative_ori, user_coord)
    if ret != SUCC:
        print("设置偏移量失败。错误码：", ret)
    # 关节运动
    joint_radian = (73.05 * pi / 180, -5.45 * pi / 180, -57.00 * pi / 180,
                    16.20 * pi / 180, -67.75 * pi / 180, 5.15 * pi / 180)
    libpyauboi5.move_joint(rshd, joint_radian)

    # 获取当前在Base坐标系下的的路点信息
    test_get_current_waypoint()
    current_waypoint = libpyauboi5.get_current_waypoint(rshd)
    flange_center_pos_on_base = current_waypoint["pos"]
    flange_center_ori_on_base = current_waypoint["ori"]
    # 工具描述
    tool_desc = {"pos": (0.10, 0.05, 0.15),
                 "ori": (1.0, 0.0, 0.0, 0.0)}
    # 工具在用户坐标系下的位置和姿态
    print("工具在用户坐标系下的位置和姿态：")
    tool_on_user = libpyauboi5.base_to_user(rshd, flange_center_pos_on_base, flange_center_ori_on_base,
                                            user_coord, tool_desc)
    print("pos: ", tool_on_user["pos"])
    tool_rpy = libpyauboi5.quaternion_to_rpy(rshd, tool_on_user["ori"])
    # 取消np的科学计数法
    np.set_printoptions(suppress=True)
    # 单位转换：弧度转角
    tool_rpy = np.array(tool_rpy) * 180 / pi
    print("rpy: ", tool_rpy)
    pass


# 测试——偏移运动：在工具坐标系下的偏移运动
def test_relative_move_on_tool():
    # 设置工具的运动学参数
    tool_desc = {
        "pos": (0.10, 0.05, 0.15),
        "ori": (1.0, 0.0, 0.0, 0.0)
    }
    libpyauboi5.set_tool_kinematics_param(rshd, tool_desc)
    # 初始化全局的运动属性
    libpyauboi5.init_global_move_profile(rshd)
    # 设置关节型运动的最大速度和最大加速度
    joint_max_acc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    joint_max_velc = (1.5, 1.5, 1.5, 1.5, 1.5, 1.5)
    libpyauboi5.set_joint_maxvelc(rshd, joint_max_velc)
    libpyauboi5.set_joint_maxacc(rshd, joint_max_acc)
    # 设置用户坐标系下的偏移
    relative_pos = (0, 0, 0)
    relative_rpy = (0, 0, 5 / 180 * pi)
    relative_ori = libpyauboi5.rpy_to_quaternion(rshd, relative_rpy)
    user_coord = {
        'coord_type': 1,
        'calibrate_method': 0,
        'calibrate_points':
            {
                "point1": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point2": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                "point3": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
            },
        'tool_desc':
            {
                "pos": (0.0, 0.0, 0.45),
                "ori": (1.0, 0.0, 0.0, 0.0)
            }
    }
    ret = libpyauboi5.set_relative_offset_on_user(rshd, relative_pos, relative_ori, user_coord)
    if ret != SUCC:
        print("设置偏移量失败。错误码：", ret)
    # 关节运动
    joint_radian = (73.05 * pi / 180, -5.45 * pi / 180, -57.00 * pi / 180,
                    16.20 * pi / 180, -67.75 * pi / 180, 5.15 * pi / 180)
    libpyauboi5.move_joint(rshd, joint_radian)

    test_get_current_waypoint()
    pass


def main():
    ip = '192.168.221.132'
    port = 8899
    if login(ip, port):
        if startup():
            # 事件信息回调
            # event_callback()
            # time.sleep(10)

            # 轴动
            # joint_move()

            # 法兰盘中心在基坐标系下, 关节运动到目标位置
            # joint_move_to_on_base1()

            # 工具在基坐标系下, 关节运动到目标位置
            # joint_move_to_on_base2()

            # 法兰盘中心在用户坐标系下, 关节运动到目标位置
            # joint_move_to_on_user1()

            # 工具在用户坐标系下, 关节运动到目标位置
            # joint_move_to_on_user2()

            # 基于跟随模式的轴动
            # follow_mode_joint_move()

            # 提前到位
            # arrival_ahead()

            # 直线运动
            # line_move()

            # 法兰盘中心在基坐标系下, 直线运动到目标位置
            # line_move_to_on_base1()

            # 工具在基坐标系下, 直线运动到目标位置
            # line_move_to_on_base2()

            # 法兰盘中心在用户坐标系下, 直线运动到目标位置
            # line_move_to_on_user1()

            # 工具在用户坐标系下, 直线运动到目标位置
            # line_move_to_on_user2()

            # 圆弧轨迹运动
            # track_move1()

            # 圆轨迹运动
            # track_move2()

            # movep轨迹运动
            # track_move3()

            # 正逆解测试
            # forward_inverse_kin()

            # 法兰盘中心在基坐标系下的旋转运动
            # rotate_move_on_base1()

            # 工具在基坐标系下的旋转运动
            # rotate_move_on_base2()

            # 法兰盘中心在用户坐标系下的旋转运动
            # rotate_move_on_user1()

            # 工具在用户坐标系下的旋转运动
            # rotate_move_on_user2()

            # 工具坐标系下的旋转运动
            # rotate_move_on_tool()

            # 离线轨迹运动
            # offline_move()

            # 法兰盘中心在基坐标系下的偏移运动
            # relative_move_on_base1()

            # 工具末端在基坐标系下的偏移运动
            # relative_move_on_base2()

            # 法兰盘中心在用户坐标系下的偏移运动
            # relative_move_on_user1()

            # 工具末端在用户坐标系下的偏移运动
            # relative_move_on_user2()

            # 在工具坐标系下的偏移运动
            # relative_move_on_tool()

            # 将法兰盘中心在基坐标系下的位置和姿态转成工具在用户坐标系下的位置和姿态
            # coord_base2user1()

            # 将法兰盘中心在基坐标系下的位置和姿态转成法兰盘中心在用户坐标系下的位置和姿态
            # coord_base2user2()

            # 将法兰盘中心在基坐标系下的位置和姿态转成工具在基坐标系下的位置和姿态
            # coord_base2user3()

            # 将法兰盘中心在基坐标系下的位置和姿态转成工具在基坐标系下的位置和姿态
            # coord_base2base()

            # 将工具末端在用户坐标系下的位置和姿态转成法兰盘中心在基坐标系下的位置和姿态
            # coord_user2base1()

            # 将法兰盘中心在用户坐标系下的位置和姿态转成法兰盘中心在基坐标系下的位置和姿态
            # coord_user2base2()

            # 将工具末端在基坐标系下的位置和姿态转成法兰盘中心在基坐标系下的位置和姿态
            # coord_user2base3()

            # TCP转CAN模式——获取关节状态
            # tcp2can_mode()

            # 工具IO
            # tool_io()

            # 用户IO
            # board_io()

            # 缩减模式
            # reduce_mode()

            # 设置和获取机械臂相关参数
            # robot_parameters()

            # 测试——获取当前路点信息
            # test_get_current_waypoint()

            # 轴动到初始位置
            # to_initial_pos()

            # 测试——获取工具在用户坐标系下的位置姿态
            #    ——获取flange_center在基坐标系下的位置姿态
            # test_base_user1()

            # 测试——获取工具在基坐标系下的位置姿态
            #    ——获取flange_center在基坐标系下的位置姿态
            # test_base_base()

            # 测试——获取flange_center在用户坐标系下的位置姿态
            #    ——获取flange_center在基坐标系下的位置姿态
            # test_base_user2()

            # 测试——旋转运动：法兰盘中心在基坐标系下的旋转
            # test_rotate_move1()

            # 测试——旋转运动：工具末端在基坐标系下的旋转
            # test_rotate_move2()

            # 测试——旋转运动：法兰盘中心在用户坐标系下的旋转
            # test_rotate_move3()

            # 测试——旋转运动：工具末端在用户坐标系下的旋转
            # test_rotate_move4()

            # 测试——旋转运动：工具坐标系下的旋转
            # test_rotate_move5()

            # 测试——偏移运动：法兰盘中心在基坐标系下的偏移运动
            # test_relative_move_on_base1()

            # 测试——偏移运动：工具末端在基坐标系下的偏移运动
            # test_relative_move_on_base2()

            # 测试——偏移运动：法兰盘中心在用户坐标系下的偏移运动
            # test_relative_move_on_user1()

            # 测试——偏移运动：工具末端在用户坐标系下的偏移运动
            # test_relative_move_on_user2()

            # 测试——偏移运动：在工具坐标系下的偏移运动
            # test_relative_move_on_tool()
            pass
        else:
            pass
    else:
        pass
    # 删除上下文句柄
    libpyauboi5.destory_context(rshd)
    # 反初始化接口libpyauboi5库
    libpyauboi5.uninitialize()
    pass


if __name__ == '__main__':
    main()
    # joint_angle = (0.54, 0.23, -0.95, 0.40, -1.57, 0.54)
    # for x in range(6):
    # print(joint_angle[x])
    # print(x)
