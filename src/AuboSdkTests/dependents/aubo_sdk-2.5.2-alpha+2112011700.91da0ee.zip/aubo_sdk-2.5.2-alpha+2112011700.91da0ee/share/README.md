# AuboSDK

**量产版本SDK，SVN最后同步日期2021-01-13**

cd D:\Program Files\Microsoft Visual Studio 9.0\VC\bin
lib /out:aubo_sdk2.lib /MACHINE:IX86 /DEF:aubo_sdk2.def  

[交叉编译](cross-compile.md)