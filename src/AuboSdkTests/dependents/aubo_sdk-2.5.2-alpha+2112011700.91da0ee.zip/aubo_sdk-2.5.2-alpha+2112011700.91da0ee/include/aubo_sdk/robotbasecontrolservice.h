#ifndef ROBOTBASECONTROLSERVICE_H
#define ROBOTBASECONTROLSERVICE_H

class RobotBaseControlService
{
public:
    RobotBaseControlService();
};

#endif // ROBOTBASECONTROLSERVICE_H
